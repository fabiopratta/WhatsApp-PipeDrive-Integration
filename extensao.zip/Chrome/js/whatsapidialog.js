

function createDiv( )
{
 console.log("ok");
}